<html>
    <head>
        <title>Questão php</title>
    </head>
    <body>
        <!--recebe valor do usuário via campo de formulario -->
        <form action="calculoimc.php" method="post">
            Digite o IMC: <input type="text" name="valorIMC"><br>
            <input type="submit">
        </form>
    <?php

        if(isset($_POST["valorIMC"])){//verifica se existe valor digitado
            $valorIMC = (float) $_POST["valorIMC"];
            calculaFaixa($valorIMC);
        }

            function calculaFaixa($valorIMC){
                $faixaIMC = array(
                    "18.5" => "Magreza",
                    "24.9" => "Saudável",
                    "29.9" => "Sobrepeso",
                    "34.9" => "Obesidade Grau I",
                    "39.9" => "Obesidade Grau II",
                    "40.0" => "Obesidade Grau III"
                );

                foreach($faixaIMC as $chave => $classificacao){
                    //Se menor que 40, exibe normalmente de magreza ate grau II.
                    //Grau III é maior ou igual a 40
                   
                    if($chave < 40.0){
                        if($valorIMC <= $chave){
                            echo PHP_EOL."Atenção! Seu IMC é ".number_format($valorIMC, 2, '.', '').", e você está classificado como "."$classificacao".'.';
                            break;
                        }
                    }else{ //Se a chave for maior ou igual a 40
                        echo PHP_EOL."Atenção! Seu IMC é ".number_format($valorIMC, 2, '.', '').", e você está classificado como "."$classificacao".'.';
                    }
                }
            }
        
    ?>
    </body>
</html>